import javax.swing.*;        // For the GUI
import java.awt.event.*;     // To click things
import java.util.Arrays;
import com.google.gson.Gson; // java obj <-> JSON string
@SuppressWarnings("unused")


public class core {	
	
	private static void createAndShowGUI() {
		// make window
		JFrame frame = new JFrame("Names Tags & Titles");
		frame.setSize(275, 80);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// define window
		JPanel panel = new JPanel();
		frame.add(panel);
		placeMenu(panel);
		
		// display window
		frame.setVisible(true);
	}
	
	private static void placeMenu(JPanel panel) {
		panel.setLayout(null);
        // note: setBounds(x, y, width, height), from top left

		// Button		
		JButton button1 = new JButton("Generate 50");
		button1.setBounds(10,10,255,25);
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				button1.setText("Another 50");	
				buttonOne("?", "?");
				}
			});
		panel.add(button1);
	
	}
	
	private static void placeScreen1(JPanel panel) {
		panel.setLayout(null);
        // note: setBounds(x, y, width, height), from top left
		// panel.add(things);
	}

	
	private static void buttonOne(String one, String two) {
		
		String trolltag = "";
		String name = "";
		Gson gson = new Gson();
		String txt = new String("");
		fio fileinterface = new fio();
		
		if (one=="") {one="?";};
		if (two=="") {two="?";};
		char a = one.charAt(0);
		char b = two.charAt(0);
				
		int x = 0;
		while (x<50) {
			name = Names.getname() + " " + Names.getname() + ", ";
			trolltag = Tags.gethandle(a, b);
			txt = txt + name + trolltag + "\n";  // new line
			x++;
			}
		fileinterface.save("names.txt",txt);
	}
		
	
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				
				createAndShowGUI();
				
			}
		});
	}
	
	
}
